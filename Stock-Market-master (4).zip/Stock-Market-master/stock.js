function Stock(/*fill*/){

    //Initialize the instance variables below


    //declare and define totalValue function below


    //declarea and define sell(q) function below
    
}

module.exports = Stock;
