function Portfolio(){
    //instance variable
    this.stocks;


    //helper function
    function findStock(trk,list){
        //i represents the index of the trk you are looking for in this.stocks
        let i;
        for(){
            if(){

            }
        }
        return i;
    }

    //instance functions
    this.add = function(stk){};
    this.update = function(tkr,val){};
    this.buy = function(tkr,qnt){};
    this.sell = function(tkr,qnt){};
    this.totalValue = function(){};
}

module.exports = Portfolio;
