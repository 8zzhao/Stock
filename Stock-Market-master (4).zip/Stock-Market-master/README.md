# Stock-Market
See Showbie for descriptions for each object.

## Stock-Group
Holds information for one particular stock.

## Portfolio
Is incharge of the whole array of stocks.
